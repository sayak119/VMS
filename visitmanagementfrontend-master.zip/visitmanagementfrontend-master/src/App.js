import React from 'react';
import EssayForm from './myform';
import Admin from './admin';
import './App.css';

function App() {
    return (
        <EssayForm/>
    );
}

export default App;
